const M={sessionLengthMinutes:25,sensitivity:"medium",enabledExercises:["blink","wrist","neck"],soundEnabled:!0,notificationsEnabled:!1,soundTheme:"soft",themeMode:"light",dailyBreakGoal:4},X=[{id:"blink",title:"Blink Exercise",shortLabel:"Eyes",duration:60,steps:[{label:"Look 20 feet away",duration:20,cue:"Relax your gaze into the distance."},{label:"Slow blink set",duration:20,cue:"Close, release, and reopen your eyes."},{label:"Soft focus reset",duration:20,cue:"Let your eyes rest before returning."}]},{id:"wrist",title:"Wrist Stretch",shortLabel:"Wrists",duration:75,steps:[{label:"Gentle rotations",duration:25,cue:"Circle both wrists slowly."},{label:"Palm flex",duration:25,cue:"Press fingers back with an easy stretch."},{label:"Release shakeout",duration:25,cue:"Shake the hands loose."}]},{id:"neck",title:"Neck Rotation",shortLabel:"Neck",duration:90,steps:[{label:"Turn left and hold",duration:30,cue:"Keep shoulders low and jaw relaxed."},{label:"Turn right and hold",duration:30,cue:"Move slowly through the center."},{label:"Forward release",duration:30,cue:"Drop chin gently and breathe."}]}],G=()=>new Date().toISOString().slice(0,10),ce=()=>({date:G(),xp:0,completed:0,partial:0,skipped:0,missed:0,blink:0,wrist:0,neck:0}),_=(e=G())=>({date:e,screenMs:0,activeMs:0,passiveMs:0,categories:{work:0,entertainment:0,social:0},socialVisits:0,scrollEvents:0,disconnectPrompts:0,eyeStrainPrompts:0}),S={xp:0,completed:0,partial:0,skipped:0,daily:ce(),completedByExercise:{blink:0,wrist:0,neck:0},usage:{today:_(),week:{}}},we=["facebook.com","instagram.com","x.com","twitter.com","tiktok.com","reddit.com","linkedin.com","threads.net","snapchat.com","pinterest.com"],ke=["youtube.com","netflix.com","twitch.tv","spotify.com","hulu.com","disneyplus.com","primevideo.com","soundcloud.com"],ve=["github.com","gitlab.com","notion.so","slack.com","docs.google.com","drive.google.com","office.com","figma.com","linear.app","jira.com","atlassian.net"],Me={low:{soft:70,urgent:90,critical:96},medium:{soft:60,urgent:85,critical:94},high:{soft:48,urgent:76,critical:90}},Se=()=>({mouseVelocity:0,idleMs:0,keypressesPerMinute:0,typingBurstCount:0,scrollVelocity:0,scrollDepth:0,visibilityChanges:0,continuousUseMinutes:0}),N=(e,n=0,i=100)=>Math.min(i,Math.max(n,e)),de=(e,n)=>{const i=Me[n];return e>=i.critical?"critical":e>=i.urgent?"urgent":e>=i.soft?"soft":"none"},Ee=(e,n,i)=>{const r=[],u=Math.min(e.continuousUseMinutes*1.55,42),h=Math.min(e.keypressesPerMinute/2.5+e.typingBurstCount*1.8,20),g=Math.min(e.mouseVelocity/46,14),m=Math.min(e.scrollVelocity/30+e.scrollDepth/11,16),a=Math.min(e.visibilityChanges*1.8,8),y=u+h+g+m+a,f=e.idleMs>45e3?Math.min(e.idleMs/2e4,16):0,b=N(n*.72+y*.28-f);return e.continuousUseMinutes>=25&&r.push("Long continuous focus session"),e.keypressesPerMinute>70&&r.push("Sustained typing intensity"),e.mouseVelocity>420&&r.push("High pointer movement"),e.scrollVelocity>260&&r.push("Rapid scrolling pattern"),e.visibilityChanges>=4&&r.push("Frequent context switching"),f>4&&r.push("Idle recovery detected"),{score:Math.round(b),urgency:de(b,i),reasons:r}},U=()=>{var e,n;try{return typeof chrome<"u"&&!!((e=chrome.runtime)!=null&&e.id&&((n=chrome.storage)!=null&&n.local))}catch{return!1}},D=async(e,n)=>{if(!U())return n;try{const i=await chrome.storage.local.get(e);return{...n,...i[e]}}catch{return n}},oe=async e=>{if(!U())return{};try{return await chrome.storage.local.get(e)}catch{return{}}},k=async e=>{if(U())try{await chrome.storage.local.set(e)}catch{}},ne=e=>{if(U())try{chrome.runtime.sendMessage(e).catch(()=>{})}catch{}},Fe=e=>{const n=e.replace(/^www\./,"");return we.some(i=>n===i||n.endsWith(`.${i}`))?"social":ke.some(i=>n===i||n.endsWith(`.${i}`))?"entertainment":(ve.some(i=>n===i||n.endsWith(`.${i}`)),"work")},ie=e=>{var n,i;return{...S,...e,daily:{...S.daily,...e==null?void 0:e.daily},completedByExercise:{...S.completedByExercise,...e==null?void 0:e.completedByExercise},usage:{today:{...S.usage.today,...(n=e==null?void 0:e.usage)==null?void 0:n.today},week:((i=e==null?void 0:e.usage)==null?void 0:i.week)??{}}}},ae=async(e,n,i)=>{await k({xpauseRuntime:{fatigueScore:e,urgency:n,reasons:i.length?i:["Activity is currently balanced"],updatedAt:Date.now()}})},V=e=>{var h,g;const n=G(),i=((h=e.usage)==null?void 0:h.today)??_(n),r={...((g=e.usage)==null?void 0:g.week)??{}};i.date!==n&&(r[i.date]=i);const u=Object.fromEntries(Object.entries(r).sort(([m],[a])=>m.localeCompare(a)).slice(-6));return{...e,daily:e.daily.date===n?e.daily:ce(),usage:{today:i.date===n?i:_(n),week:u}}},De=(e,n,i,r)=>{const u=e.screenMs>0?e.passiveMs/e.screenMs:0,h=Math.round(e.categories.social/6e4),g=Math.round(e.categories.entertainment/6e4),m=[i>=20?"Run a 20-20-20 eye reset now.":`Next eye reset in ${Math.max(1,20-i)} min.`,u>.62?"Use shorter 8-12 minute browsing blocks with a hard stop.":"Keep the next focus block around 25 minutes.",h>30||r>=65?"Take a 15 minute social disconnect before returning.":g>45?"Switch to a work or recovery tab before more entertainment.":"Micro-break timing looks balanced."];return{socialFatigueScore:r,eyeStrainMinutes:i,category:n,passiveRatio:u,schedule:m,disconnectSuggestion:r>=75?"Disconnect strongly recommended.":r>=55?"Consider closing social tabs for one focus block.":"No disconnect needed yet.",updatedAt:Date.now()}},Ae=e=>{const n=e.enabledExercises.length?e.enabledExercises:M.enabledExercises,i=n[Math.floor(Math.random()*n.length)];return X.find(r=>r.id===i)??X[0]},Te=e=>{const n={soft:[{frequency:520,start:0,duration:.34,gain:.026},{frequency:660,start:.42,duration:.42,gain:.02}],chime:[{frequency:620,start:0,duration:.24,gain:.024},{frequency:820,start:.28,duration:.28,gain:.022},{frequency:980,start:.62,duration:.38,gain:.018}],pulse:[{frequency:420,start:0,duration:.18,gain:.028},{frequency:420,start:.28,duration:.18,gain:.026},{frequency:560,start:.58,duration:.28,gain:.022}]};return e==="custom"?n.soft:n[e]},re=e=>e!=="system"?e:window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light",Ce=()=>`
  :host { all: initial; color-scheme: light dark; }
  .xp-panel {
    position: fixed;
    right: 18px;
    bottom: 18px;
    z-index: 2147483647;
    width: min(390px, calc(100vw - 28px));
    box-sizing: border-box;
    border: 1px solid #E2E8F0;
    border-radius: 10px;
    background: #FFFFFF;
    color: #172033;
    box-shadow: 0 22px 70px rgba(15, 23, 42, .18);
    font-family: Inter, system-ui, sans-serif;
    padding: 16px;
  }
  .xp-panel.xp-theme-dark {
    border-color: rgba(148, 163, 184, .16);
    background: #111827;
    color: #E5EDF6;
    box-shadow: 0 22px 70px rgba(0, 0, 0, .38);
  }
  .xp-panel.critical { border-color: rgba(225, 29, 72, .72); box-shadow: 0 0 0 9999px rgba(15, 23, 42, .18), 0 22px 70px rgba(15, 23, 42, .18); }
  .xp-panel.xp-theme-dark.critical { box-shadow: 0 0 0 9999px rgba(13, 27, 42, .42), 0 22px 70px rgba(0, 0, 0, .38); }
  .xp-top, .xp-actions, .xp-dots { display: flex; align-items: center; }
  .xp-top { justify-content: space-between; gap: 12px; }
  .xp-eyebrow { margin: 0 0 4px; color: #0284C7; font: 700 11px/1 Inter, sans-serif; text-transform: uppercase; }
  h2, h3, p { margin: 0; }
  h2 { font: 700 22px/1.15 Space Grotesk, Inter, sans-serif; }
  h3 { font: 700 18px/1.25 Space Grotesk, Inter, sans-serif; text-align: center; }
  p { color: #475569; font: 500 14px/1.5 Inter, sans-serif; }
  .xp-theme-dark p { color: #CBD5E1; }
  .xp-theme-dark .xp-eyebrow { color: #38BDF8; }
  button { min-height: 40px; border: 0; border-radius: 8px; font: 700 13px/1 Inter, sans-serif; cursor: pointer; }
  .xp-close { width: 38px; background: #F1F5F9; color: #172033; }
  .xp-theme-dark .xp-close { background: rgba(255,255,255,.08); color: #E5EDF6; }
  .xp-visual { display: grid; place-items: center; height: 116px; margin: 16px 0; border: 1px solid #E2E8F0; border-radius: 9px; background: #F8FAFC; overflow: hidden; }
  .xp-theme-dark .xp-visual { border-color: rgba(148, 163, 184, .14); background: rgba(15, 23, 42, .72); }
  .xp-shape { display: block; width: 74px; height: 74px; }
  .blink .xp-shape { height: 42px; border: 4px solid #16A34A; border-radius: 50%; animation: xpBlink 3s ease-in-out infinite; }
  .wrist .xp-shape { border: 5px solid #0284C7; border-left-color: transparent; border-radius: 50%; animation: xpRotate 2.6s linear infinite; }
  .neck .xp-shape { width: 54px; height: 68px; border-radius: 45% 45% 40% 40%; background: #D97706; animation: xpNeck 3s ease-in-out infinite; }
  .xp-ring { display: grid; place-items: center; width: 112px; height: 112px; margin: 0 auto 14px; border-radius: 50%; background: radial-gradient(circle closest-side, #FFFFFF 72%, transparent 73%), conic-gradient(#16A34A var(--progress), #E2E8F0 0); }
  .xp-theme-dark .xp-ring { background: radial-gradient(circle closest-side, #111827 72%, transparent 73%), conic-gradient(#22C55E var(--progress), rgba(240,237,230,.12) 0); }
  .xp-ring strong { align-self: end; font: 700 36px/1 Space Grotesk, Inter, sans-serif; }
  .xp-ring span { align-self: start; color: #64748B; font: 600 12px/1 Inter, sans-serif; }
  .xp-theme-dark .xp-ring span { color: #94A3B8; }
  .xp-copy { display: grid; gap: 7px; margin: 0 0 12px; text-align: center; }
  .xp-dots { justify-content: center; gap: 7px; margin: 0 0 14px; }
  .xp-dots span { width: 32px; height: 6px; border-radius: 999px; background: #E2E8F0; }
  .xp-theme-dark .xp-dots span { background: rgba(240,237,230,.14); }
  .xp-dots span.active { background: #16A34A; }
  .xp-actions { justify-content: flex-end; flex-wrap: wrap; gap: 8px; }
  .xp-secondary { padding: 0 12px; border: 1px solid #CBD5E1; background: #FFFFFF; color: #172033; }
  .xp-theme-dark .xp-secondary { border-color: rgba(157,180,192,.28); background: rgba(255,255,255,.07); color: #E5EDF6; }
  .xp-primary { padding: 0 14px; background: #0284C7; color: #FFFFFF; }
  .xp-reminder-mark {
    display: grid;
    place-items: center;
    width: 46px;
    height: 46px;
    border-radius: 10px;
    background: #E7F6FE;
    color: #0369A1;
    font: 800 18px/1 Inter, sans-serif;
  }
  .xp-theme-dark .xp-reminder-mark { background: rgba(56, 189, 248, .14); color: #38BDF8; }
  .xp-reminder-body {
    display: grid;
    gap: 10px;
    margin: 16px 0;
    border: 1px solid #E2E8F0;
    border-radius: 9px;
    background: #F8FAFC;
    padding: 12px;
  }
  .xp-theme-dark .xp-reminder-body { border-color: rgba(148, 163, 184, .14); background: rgba(15, 23, 42, .72); }
  .xp-reminder-stat {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    color: #475569;
    font: 700 13px/1 Inter, sans-serif;
  }
  .xp-theme-dark .xp-reminder-stat { color: #CBD5E1; }
  .xp-reminder-stat strong { color: #172033; font-size: 22px; }
  .xp-theme-dark .xp-reminder-stat strong { color: #E5EDF6; }
  @keyframes xpBlink { 0%, 65%, 100% { transform: scaleY(1); } 72% { transform: scaleY(.08); } }
  @keyframes xpRotate { to { transform: rotate(360deg); } }
  @keyframes xpNeck { 0%,100% { transform: translateX(-12px) rotate(-6deg); } 50% { transform: translateX(12px) rotate(6deg); } }
  @media (prefers-reduced-motion: reduce) { * { animation-duration: .01ms !important; animation-iteration-count: 1 !important; transition-duration: .01ms !important; } }
`,$e=()=>{if(window.top!==window||document.getElementById("xpause-extension-root"))return;const e=document.createElement("div");e.id="xpause-extension-root";const n=e.attachShadow({mode:"open"}),i=document.createElement("style");i.textContent=Ce();const r=document.createElement("div");n.append(i,r),document.documentElement.append(e);let u=0,h=0,g=0,m=null,a=null,y="soft",f=0,b=null;const x=Se(),v={x:0,y:0,time:Date.now()},A={y:window.scrollY,time:Date.now()};let T=Date.now(),O=Date.now(),Y=!1,d=M,E=[],z=Date.now(),W=Date.now(),K=Date.now(),J=0,Q=0,Z=0;const C=Fe(location.hostname),$=()=>{const t=Date.now();t-T>5*6e4&&(O=t),T=t,z=t},le=async t=>{const s=new Audio(t);s.volume=.78,s.currentTime=0,await s.play().catch(()=>{}),window.setTimeout(()=>{s.pause(),s.currentTime=0},2e3)},H=async()=>{if(!d.soundEnabled)return;if(d.soundTheme==="custom"&&d.customSoundDataUrl){await le(d.customSoundDataUrl).catch(()=>{});return}const t=window.AudioContext||window.webkitAudioContext;if(!t)return;const s=new t;Te(d.soundTheme).forEach(o=>{const c=s.createOscillator(),l=s.createGain();c.type=d.soundTheme==="pulse"?"triangle":"sine",c.frequency.setValueAtTime(o.frequency,s.currentTime+o.start),l.gain.setValueAtTime(1e-4,s.currentTime+o.start),l.gain.exponentialRampToValueAtTime(o.gain,s.currentTime+o.start+.03),l.gain.exponentialRampToValueAtTime(1e-4,s.currentTime+o.start+o.duration),c.connect(l).connect(s.destination),c.start(s.currentTime+o.start),c.stop(s.currentTime+o.start+o.duration+.04)}),window.setTimeout(()=>void s.close().catch(()=>{}),1500)},j=()=>{if(!a)return 0;let t=0;for(let s=0;s<a.steps.length;s+=1)if(t+=a.steps[s].duration,f<t)return s;return a.steps.length-1},ee=async(t,s)=>{const o=V(await D("xpauseStats",S)),c=s?50:100,l={...o,xp:o.xp+c,completed:o.completed+(s?0:1),partial:o.partial+(s?1:0),daily:{...o.daily,xp:o.daily.xp+c,completed:o.daily.completed+(s?0:1),partial:o.daily.partial+(s?1:0),[t.id]:o.daily[t.id]+1},completedByExercise:{...o.completedByExercise,[t.id]:o.completedByExercise[t.id]+1}};u=Math.max(0,u-(s?28:55)),await k({xpauseStats:l}),await ae(u,"none",["Break completed"])},te=async t=>{const s=V(await D("xpauseStats",S)),o={...s,skipped:s.skipped+(t==="skipped"?1:0),daily:{...s.daily,skipped:s.daily.skipped+(t==="skipped"?1:0),missed:s.daily.missed+1}};await k({xpauseStats:o})},F=()=>{b&&window.clearInterval(b),b=null,a=null,y="soft",f=0,r.innerHTML=""},P=()=>{m=null,r.innerHTML=""},B=(t,s="soft",o=!0)=>{if(a)return;m=t,y=s,o&&H();const c=`xp-theme-${re(d.themeMode)}`,l=t==="social",w=l?h:u;r.innerHTML=`
      <aside class="xp-panel ${c} ${s}" role="dialog" aria-modal="${s==="critical"}" aria-labelledby="xpause-reminder-title">
        <div class="xp-top">
          <div>
            <p class="xp-eyebrow">${l?"Social disconnect":"Fatigue reminder"}</p>
            <h2 id="xpause-reminder-title">${l?"Step away from social feeds":"Your focus load is high"}</h2>
          </div>
          <span class="xp-reminder-mark" aria-hidden="true">${l?"S":"F"}</span>
        </div>
        <div class="xp-reminder-body">
          <p>${l?"Your social fatigue score is elevated. A short disconnect can make the next focus block feel lighter.":"Your fatigue score is elevated. Take a guided reset before continuing."}</p>
          <div class="xp-reminder-stat"><span>${l?"Social score":"Fatigue score"}</span><strong>${w}</strong></div>
        </div>
        <div class="xp-actions">
          <button class="xp-secondary" type="button" data-action="reminder-snooze">Snooze</button>
          <button class="xp-secondary" type="button" data-action="reminder-dismiss">Dismiss</button>
          <button class="xp-primary" type="button" data-action="${l?"disconnect":"start-reset"}">${l?"Disconnect 15m":"Start reset"}</button>
        </div>
      </aside>
    `},I=t=>{if(!a)return;const s=j(),o=a.steps[s],c=Math.max(0,a.duration-f),l=Math.min(100,f/a.duration*100),w=`xp-theme-${re(d.themeMode)}`;r.innerHTML=`
      <aside class="xp-panel ${w} ${t}" role="dialog" aria-modal="${t==="critical"}" aria-labelledby="xpause-title">
        <div class="xp-top">
          <div>
            <p class="xp-eyebrow">${t==="critical"?"Critical reset":"XPause micro-break"}</p>
            <h2 id="xpause-title">${a.title}</h2>
          </div>
          <button class="xp-close" type="button" data-action="close" aria-label="Dismiss">X</button>
        </div>
        <div class="xp-visual ${a.id}" aria-hidden="true"><span class="xp-shape"></span></div>
        <div class="xp-ring" style="--progress: ${l}%"><strong>${c}</strong><span>sec</span></div>
        <div class="xp-copy"><h3>${o.label}</h3><p>${o.cue}</p></div>
        <div class="xp-dots" aria-label="Step ${s+1} of ${a.steps.length}">
          ${a.steps.map((p,R)=>`<span class="${R<=s?"active":""}" title="${p.label}"></span>`).join("")}
        </div>
        <div class="xp-actions">
          <button class="xp-secondary" type="button" data-action="snooze">Snooze</button>
          <button class="xp-secondary" type="button" data-action="skip">Skip</button>
          <button class="xp-primary" type="button" data-action="done">Done</button>
        </div>
      </aside>
    `},q=async(t="soft",s,o)=>{a||(d=o??await D("xpauseSettings",M),a=s??Ae(d),y=t,f=0,H(),I(t),d.notificationsEnabled&&ne({type:"XP_PAUSE_NOTIFY",body:`${a.title} is ready. Your fatigue score is ${u}.`}),b=window.setInterval(()=>{if(!a)return;const c=j();f+=1,j()!==c&&H(),f>=a.duration?(ee(a,!1),F()):I(t)},1e3))};r.addEventListener("click",t=>{const o=t.target.dataset.action;if(o){if(m){o==="start-reset"&&(P(),q(y)),o==="disconnect"&&(g=Date.now()+15*6e4,P()),o==="reminder-snooze"&&(g=Date.now()+10*6e4,P()),o==="reminder-dismiss"&&P();return}a&&(o==="close"&&F(),o==="done"&&(ee(a,f<a.duration*.75),F()),o==="skip"&&(te("skipped"),F()),o==="snooze"&&(g=Date.now()+10*6e4,te("snoozed"),F()))}});const pe=t=>{const s=Date.now(),o=Math.hypot(t.clientX-v.x,t.clientY-v.y),c=Math.max((s-v.time)/1e3,.016);x.mouseVelocity=x.mouseVelocity*.78+o/c*.22,v.x=t.clientX,v.y=t.clientY,v.time=s,$()},ue=()=>{$()},me=()=>{const t=Date.now();E=[...E,t].filter(o=>t-o<6e4);const s=E.filter(o=>t-o<5e3);s.length>=12&&!Y&&(x.typingBurstCount+=1,Y=!0),s.length<4&&(Y=!1),$()},xe=()=>{const t=Date.now(),s=Math.abs(window.scrollY-A.y),o=Math.max((t-A.time)/1e3,.016),c=Math.max(document.documentElement.scrollHeight-window.innerHeight,window.innerHeight);x.scrollVelocity=x.scrollVelocity*.76+s/o*.24,x.scrollDepth=Math.max(x.scrollDepth,Math.round(window.scrollY/c*100)),A.y=window.scrollY,A.time=t,T=t,z=t},ge=()=>{x.visibilityChanges+=1,document.hidden||$()};window.addEventListener("pointermove",pe,{passive:!0}),window.addEventListener("click",ue,{passive:!0}),window.addEventListener("keydown",me),window.addEventListener("scroll",xe,{passive:!0}),document.addEventListener("visibilitychange",ge),C==="social"&&(async()=>{const t=V(ie((await oe("xpauseStats")).xpauseStats));t.usage.today.socialVisits+=1,await k({xpauseStats:t})})(),chrome.runtime.onMessage.addListener(t=>{if(!t||typeof t!="object"||!("type"in t))return;const s="settings"in t&&t.settings&&typeof t.settings=="object"?{...M,...t.settings}:null;t.type==="XP_PAUSE_START_BREAK"&&(s&&(d=s),q("soft",void 0,s??void 0)),t.type==="XP_PAUSE_SETTINGS_UPDATED"&&(s?(d=s,a&&I(y),m&&B(m,y,!1)):D("xpauseSettings",M).then(o=>{d=o,a&&I(y),m&&B(m,y,!1)}))}),window.setInterval(()=>{(async()=>{d=await D("xpauseSettings",M);const t=Date.now(),s=document.hidden?0:Math.max(0,t-W);W=t;const o=t-T;o>5*6e4&&(K=t);const c=Math.max((t-O)/6e4,d.sessionLengthMinutes-25),l={...x,idleMs:o,keypressesPerMinute:E.filter(be=>t-be<6e4).length,continuousUseMinutes:c},w=Ee(l,u,d.sensitivity);u=o>3e4?Math.round(N(u-Math.min(o/12e3,24))):w.score;const p=V(ie((await oe("xpauseStats")).xpauseStats)),R=t-z<15e3&&(E.length>0||x.mouseVelocity>80);p.usage.today.screenMs+=s,p.usage.today.categories[C]+=s,p.usage.today.activeMs+=R?s:0,p.usage.today.passiveMs+=R?0:s,p.usage.today.scrollEvents+=x.scrollVelocity>80?1:0;const he=p.usage.today.categories.social/6e4,ye=p.usage.today.screenMs>0?p.usage.today.passiveMs/p.usage.today.screenMs:0;h=Math.round(N(he*1.45+ye*32+Math.min(p.usage.today.scrollEvents/2,20)));const se=Math.floor((t-K)/6e4),fe=De(p.usage.today,C,se,h);await k({xpauseStats:p,xpauseInsights:fe});const L=o>3e4?de(u,d.sensitivity):w.urgency;await ae(u,L,w.reasons),se>=20&&t-J>20*6e4&&!a&&(J=t,p.usage.today.eyeStrainPrompts+=1,await k({xpauseStats:p}),q("soft",X[0])),h>=70&&C==="social"&&t>g&&t-Q>15*6e4&&!a&&!m&&(Q=t,p.usage.today.disconnectPrompts+=1,await k({xpauseStats:p}),B("social","urgent"),d.notificationsEnabled&&ne({type:"XP_PAUSE_NOTIFY",body:"Social fatigue is high. Consider disconnecting for 15 minutes."})),L!=="none"&&!a&&!m&&Date.now()>g&&t-Z>10*6e4&&(Z=t,y=L,B("fatigue",L)),x.typingBurstCount=Math.max(0,x.typingBurstCount-1),x.visibilityChanges=Math.max(0,x.visibilityChanges-1)})()},5e3)};$e();
//# sourceMappingURL=contentScript.js.map
