chrome.runtime.onMessage.addListener(i=>{if(!(!i||typeof i!="object"||!("type"in i))&&i.type==="XP_PAUSE_NOTIFY"){const t={type:"basic",iconUrl:chrome.runtime.getURL("icon.svg"),title:"XPause",message:"body"in i&&typeof i.body=="string"?i.body:"A micro-break is ready.",priority:1};chrome.notifications.create(`xpause-${Date.now()}`,t).catch(()=>{})}});
//# sourceMappingURL=background.js.map
